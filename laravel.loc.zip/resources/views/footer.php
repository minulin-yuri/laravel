<footer class="footer">
    <div class="container footer__container">
        <p>&copy; Copyright
            <?= date("Y") ?>
        </p>
    </div>
</footer>