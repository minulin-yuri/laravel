<section class="nav">
    <div class="container nav__container">
        <div class="nav__menu">
            <?php for ($i = 1; $i < 7; $i++) : ?>
                <a href="/" class="nav__menu__link upper_text">menu <?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
</section>